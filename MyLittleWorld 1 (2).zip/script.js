function addTask() {
    let input = document.getElementById("taskInput");
    let task = input.value;

    if (task.trim() === "") {
        return;
    }

    let li = document.createElement("li");
    li.textContent = task;

    li.onclick = function() {
        li.style.textDecoration = "line-through";
        li.style.opacity = "0.5";
    };

    document.getElementById("taskList").appendChild(li);

    input.value = "";
}
document.body.style.backgroundColor = "lightblue";